<?php
/**
 * Default Lexicon Entries for AjaxUpload
 *
 * @package ajaxupload
 * @subpackage lexicon
 */
$_lang['ajaxupload'] = 'AjaxUpload';
$_lang['ajaxupload.cacheNotCreatable'] = 'Der Cache-Ordner konnte nicht erstellt werden!';
$_lang['ajaxupload.filledFileNotFound'] = 'Die angegebene Datei konnte nicht gefunden werden.';
$_lang['ajaxupload.missingParameterAjaxuploadTarget'] = 'Fehlender Parameter ajaxuploadTarget.';
$_lang['ajaxupload.missingParameterAjaxuploadTargetRelativePath'] = 'Fehlender Parameter ajaxuploadTargetRelativePath.';
$_lang['ajaxupload.targetNotCreatable'] = 'Der Zielordner konnte nicht erstellt werden!';
$_lang['ajaxupload.uploadRequired'] = 'Sie müssen mindestens eine Datei hochladen!';
