<?php
/**
 * AjaxUpload
 *
 * Copyright 2013-2023 by Thomas Jakobi <office@treehillstudio.com>
 *
 * @package ajaxupload
 * @subpackage classfile
 */

require_once dirname(__DIR__, 2) . '/vendor/autoload.php';

/**
 * class AjaxUpload
 */
class AjaxUpload extends \TreehillStudio\AjaxUpload\AjaxUpload
{
}
