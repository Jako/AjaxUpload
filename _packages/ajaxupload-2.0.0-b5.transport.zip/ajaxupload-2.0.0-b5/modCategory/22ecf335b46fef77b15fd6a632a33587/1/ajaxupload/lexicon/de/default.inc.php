<?php
/**
 * Default Lexicon Entries for AjaxUpload
 *
 * @package ajaxupload
 * @subpackage lexicon
 */
$_lang['ajaxupload'] = 'AjaxUpload';
$_lang['ajaxupload.targetNotCreatable'] = 'Der Zielordner konnte nicht erstellt werden!';
$_lang['ajaxupload.uploadRequired'] = 'Sie müssen mindestens eine Datei hochladen!';
