<?php
/**
 * Setting Lexicon Entries for AjaxUpload
 *
 * @package ajaxupload
 * @subpackage lexicon
 */
$_lang['setting_ajaxupload.cache_expires'] = 'Ablaufzeit';
$_lang['setting_ajaxupload.cache_expires_desc'] = 'Ablaufzeit des AjaxUpload-Cache (in Stunden)';
$_lang['setting_ajaxupload.debug'] = 'Debug';
$_lang['setting_ajaxupload.debug_desc'] = 'Debug-Informationen im MODX Fehlerprotokoll ausgeben.';
