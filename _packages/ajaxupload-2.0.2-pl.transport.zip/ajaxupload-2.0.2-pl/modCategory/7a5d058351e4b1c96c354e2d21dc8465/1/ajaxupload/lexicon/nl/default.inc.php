<?php
/**
 * Default Lexicon Entries for AjaxUpload
 *
 * @package ajaxupload
 * @subpackage lexicon
 */
$_lang['ajaxupload'] = 'AjaxUpload';
$_lang['ajaxupload.cacheNotCreatable'] = 'Kan de cache-map niet maken!';
$_lang['ajaxupload.filledFileNotFound'] = 'Het opgegeven bestand kon niet worden gevonden.';
$_lang['ajaxupload.missingParameterAjaxuploadTarget'] = 'Parameter ajaxuploadTarget ontbreekt.';
$_lang['ajaxupload.targetNotCreatable'] = 'Kan de doelmap niet maken!';
$_lang['ajaxupload.uploadRequired'] = 'U moet ten minste één bestand uploaden!';
