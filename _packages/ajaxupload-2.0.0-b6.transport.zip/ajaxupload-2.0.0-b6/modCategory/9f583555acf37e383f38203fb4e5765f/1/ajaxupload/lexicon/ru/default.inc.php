<?php
/**
 * Default Lexicon Entries for AjaxUpload
 *
 * @package ajaxupload
 * @subpackage lexicon
 */
$_lang['ajaxupload'] = 'AjaxUpload';
$_lang['ajaxupload.targetNotCreatable'] = 'Не удалось создать целевую папку!';
$_lang['ajaxupload.uploadRequired'] = 'Вы должны загрузить хотя бы один файл!';
