<?php
/**
 * Default Lexicon Entries for AjaxUpload
 *
 * @package ajaxupload
 * @subpackage lexicon
 */
$_lang['ajaxupload'] = 'AjaxUpload';
$_lang['ajaxupload.targetNotCreatable'] = 'Kan de doelmap niet maken!';
$_lang['ajaxupload.uploadRequired'] = 'U moet ten minste één bestand uploaden!';
